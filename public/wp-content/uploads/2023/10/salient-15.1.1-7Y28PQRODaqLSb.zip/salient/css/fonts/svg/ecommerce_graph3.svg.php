<!-- Generator: Adobe Illustrator 16.0.0, SVG Export Plug-In . SVG Version: 6.00 Build 0)  -->
<svg version="1.0"  xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
	 width="64px" height="64px" viewBox="0 0 64 64" enable-background="new 0 0 64 64" xml:space="preserve">
<circle fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" cx="56" cy="34" r="3"/>
<circle fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" cx="22" cy="4" r="3"/>
<circle fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" cx="40" cy="50" r="3"/>
<circle fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" cx="7" cy="31" r="3"/>
<line fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" x1="8" y1="28" x2="20" y2="6"/>
<line fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" x1="43" y1="48" x2="54" y2="36"/>
<rect x="1" y="57" fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" width="62" height="6"/>
<line fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" x1="24" y1="6" x2="38" y2="47"/>
</svg>
