<!-- Generator: Adobe Illustrator 16.0.0, SVG Export Plug-In . SVG Version: 6.00 Build 0)  -->
<svg version="1.0"  xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
	 width="64px" height="64px" viewBox="0 0 64 64" enable-background="new 0 0 64 64" xml:space="preserve">
<path fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" d="M24,42c0,4.418,3.582,8,8,8s8-3.582,8-8V1h13v41
	c0,11.598-9.402,21-21,21s-21-9.402-21-21V1h13V42z"/>
<line fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" x1="11" y1="10" x2="24" y2="10"/>
<line fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" x1="40" y1="10" x2="53" y2="10"/>
</svg>
