<!-- Generator: Adobe Illustrator 16.0.0, SVG Export Plug-In . SVG Version: 6.00 Build 0)  -->
<svg version="1.1"  xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
	 width="64px" height="64px" viewBox="0 0 64 64" enable-background="new 0 0 64 64" xml:space="preserve">
<g>
	<rect x="8" y="12" fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" width="48" height="34"/>
	<rect x="1" y="46" fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" width="62" height="6"/>
	<line fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" x1="34" y1="16" x2="30" y2="16"/>
</g>
</svg>
