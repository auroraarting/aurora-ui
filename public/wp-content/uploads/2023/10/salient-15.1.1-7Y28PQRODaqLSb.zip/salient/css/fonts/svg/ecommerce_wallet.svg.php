<!-- Generator: Adobe Illustrator 16.0.0, SVG Export Plug-In . SVG Version: 6.00 Build 0)  -->
<svg version="1.0"  xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
	 width="64px" height="64px" viewBox="0 0 64 64" enable-background="new 0 0 64 64" xml:space="preserve">
<polyline fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" points="61,44 61,55 1,55 1,15 61,15 61,26 "/>
<polyline fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" points="6,9 54,9 54,15 "/>
<path fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" d="M6,9c-2.762,0-5,2.239-5,5"/>
<path fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" d="M43.125,26c-4.972,0-9,4.029-9,9c0,4.97,4.028,9,9,9
	H63V26H43.125z"/>
<circle fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" cx="44" cy="35" r="3"/>
</svg>
