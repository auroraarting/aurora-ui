<!-- Generator: Adobe Illustrator 16.0.0, SVG Export Plug-In . SVG Version: 6.00 Build 0)  -->
<svg version="1.1"  xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
	 width="64px" height="64px" viewBox="0 0 64 64" enable-background="new 0 0 64 64" xml:space="preserve">
<line fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" x1="32" y1="40" x2="32" y2="64"/>
<line fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" x1="32" y1="0" x2="32" y2="24"/>
<line fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" x1="38" y1="37" x2="59" y2="54"/>
<line fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" x1="5" y1="10" x2="26" y2="27"/>
<line fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" x1="38" y1="27" x2="59" y2="11"/>
<line fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" x1="5" y1="53" x2="26" y2="37"/>
<circle fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" cx="32" cy="32" r="8"/>
<circle fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" cx="32" cy="32" r="24"/>
</svg>
