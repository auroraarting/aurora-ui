<!-- Generator: Adobe Illustrator 16.0.0, SVG Export Plug-In . SVG Version: 6.00 Build 0)  -->
<svg version="1.0"  xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
	 width="64px" height="64px" viewBox="0 0 64 64" enable-background="new 0 0 64 64" xml:space="preserve">
<g>
	<g>
		<polyline fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" points="63,50 63,52 61,52 		"/>
		
			<line fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" stroke-dasharray="4,2" x1="59" y1="52" x2="4" y2="52"/>
		<polyline fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" points="3,52 1,52 1,50 		"/>
		
			<line fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" stroke-dasharray="4,2" x1="1" y1="48" x2="1" y2="15"/>
		<polyline fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" points="1,14 1,12 3,12 		"/>
		
			<line fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" stroke-dasharray="4,2" x1="5" y1="12" x2="60" y2="12"/>
		<polyline fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" points="61,12 63,12 63,14 		"/>
		
			<line fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" stroke-dasharray="4,2" x1="63" y1="16" x2="63" y2="49"/>
	</g>
</g>
</svg>
