<!-- Generator: Adobe Illustrator 16.0.0, SVG Export Plug-In . SVG Version: 6.00 Build 0)  -->
<svg version="1.1"  xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
	 width="64px" height="64px" viewBox="0 0 64 64" enable-background="new 0 0 64 64" xml:space="preserve">
<path fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" d="M44,40c0,3.866,3.134,7,7,7s7-3.134,7-7
	s-3.134-7-7-7H0"/>
<path fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" d="M49,19c0-3.866,3.134-7,7-7s7,3.134,7,7
	s-3.134,7-7,7H0"/>
<path fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" d="M27,45c0,2.761,2.239,5,5,5s5-2.239,5-5
	s-2.239-5-5-5H0"/>
</svg>
