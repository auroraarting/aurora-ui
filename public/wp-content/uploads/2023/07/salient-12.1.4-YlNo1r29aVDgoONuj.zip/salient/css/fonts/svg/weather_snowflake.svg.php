<!-- Generator: Adobe Illustrator 16.0.0, SVG Export Plug-In . SVG Version: 6.00 Build 0)  -->
<svg version="1.1"  xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
	 width="64px" height="64px" viewBox="0 0 64 64" enable-background="new 0 0 64 64" xml:space="preserve">
<polyline fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" points="1,24 9,32 1,40 "/>
<polyline fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" points="63,40 55,32 63,24 "/>
<polyline fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" points="24,63 32,55 40,63 "/>
<polyline fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" points="40,1 32,9 24,1 "/>
<polyline fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" points="5,49 15,49 15,59 "/>
<polyline fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" points="59,15 49,15 49,5 "/>
<line fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" x1="38" y1="26" x2="49" y2="15"/>
<line fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" x1="15" y1="49" x2="26" y2="38"/>
<polyline fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" points="15,5 15,15 5,15 "/>
<polyline fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" points="49,59 49,49 59,49 "/>
<line fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" x1="38" y1="38" x2="49" y2="49"/>
<line fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" x1="15" y1="15" x2="26" y2="26"/>
<line fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" x1="40" y1="32" x2="55" y2="32"/>
<line fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" x1="9" y1="32" x2="24" y2="32"/>
<line fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" x1="32" y1="40" x2="32" y2="55"/>
<line fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" x1="32" y1="9" x2="32" y2="24"/>
<circle fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" cx="32" cy="32" r="8"/>
</svg>
