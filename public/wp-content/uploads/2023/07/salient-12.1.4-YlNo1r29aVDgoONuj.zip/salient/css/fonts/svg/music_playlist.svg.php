<!-- Generator: Adobe Illustrator 16.0.0, SVG Export Plug-In . SVG Version: 6.00 Build 0)  -->
<svg version="1.1"  xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
	 width="64px" height="64px" viewBox="0 0 64 64" enable-background="new 0 0 64 64" xml:space="preserve">
<g>
	<circle fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" cx="35" cy="55" r="8"/>
	<polyline fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" points="43,55 43,7 63,1 63,15 43,21 	"/>
</g>
<line fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" x1="4" y1="16" x2="38" y2="16"/>
<line fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" x1="4" y1="26" x2="38" y2="26"/>
<line fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" x1="4" y1="36" x2="38" y2="36"/>
</svg>
