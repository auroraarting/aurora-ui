<!-- Generator: Adobe Illustrator 16.0.0, SVG Export Plug-In . SVG Version: 6.00 Build 0)  -->
<svg version="1.1"  xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
	 width="64px" height="64px" viewBox="0 0 64 64" enable-background="new 0 0 64 64" xml:space="preserve">
<g>
	<circle fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" cx="22" cy="55" r="8"/>
	<polyline fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" points="30,55 30,7 50,1 50,15 30,21 	"/>
</g>
</svg>
