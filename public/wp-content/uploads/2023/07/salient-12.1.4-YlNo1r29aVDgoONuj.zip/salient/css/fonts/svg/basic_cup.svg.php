<!-- Generator: Adobe Illustrator 16.0.0, SVG Export Plug-In . SVG Version: 6.00 Build 0)  -->
<svg version="1.1"  xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
	 width="64px" height="64px" viewBox="0 0 64 64" enable-background="new 0 0 64 64" xml:space="preserve">
<path fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" d="M16,27c0,4.418,6.059,8,16,8s16-3.582,16-8V1H16V27z
	"/>
<line fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" x1="20" y1="63" x2="44" y2="63"/>
<line fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" x1="32" y1="35" x2="32" y2="63"/>
<path fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" d="M16,7H7c0,0,0,9,9,9"/>
<path fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" d="M48,7h9c0,0,0,9-9,9"/>
</svg>
