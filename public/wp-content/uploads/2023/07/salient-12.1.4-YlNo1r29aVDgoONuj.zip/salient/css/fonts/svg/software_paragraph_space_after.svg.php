<!-- Generator: Adobe Illustrator 16.0.0, SVG Export Plug-In . SVG Version: 6.00 Build 0)  -->
<svg version="1.0"  xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
	 width="64px" height="64px" viewBox="0 0 64 64" enable-background="new 0 0 64 64" xml:space="preserve">
<line fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" x1="22" y1="6" x2="64" y2="6"/>
<line fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" x1="22" y1="16" x2="56" y2="16"/>
<line fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" x1="22" y1="26" x2="64" y2="26"/>
<line fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" x1="22" y1="36" x2="58" y2="36"/>
<g>
	<g>
		<polyline fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" points="59,48 59,46 57,46 		"/>
		
			<line fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" stroke-dasharray="4,2" x1="55" y1="46" x2="26" y2="46"/>
		<polyline fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" points="25,46 23,46 23,48 		"/>
		
			<line fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" stroke-dasharray="3,2" x1="23" y1="50" x2="23" y2="53"/>
		<polyline fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" points="23,54 23,56 25,56 		"/>
		
			<line fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" stroke-dasharray="4,2" x1="27" y1="56" x2="56" y2="56"/>
		<polyline fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" points="57,56 59,56 59,54 		"/>
		
			<line fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" stroke-dasharray="3,2" x1="59" y1="53" x2="59" y2="49"/>
	</g>
</g>
<g>
	<polyline fill="none" stroke="#000000" stroke-width="2" stroke-linejoin="bevel" stroke-miterlimit="10" points="10,58 17,51 
		10,44 	"/>
	<g>
		<line fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" x1="17" y1="51" x2="0" y2="51"/>
	</g>
</g>
</svg>
