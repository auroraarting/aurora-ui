<!-- Generator: Adobe Illustrator 16.0.0, SVG Export Plug-In . SVG Version: 6.00 Build 0)  -->
<svg version="1.0"  xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
	 width="64px" height="64px" viewBox="0 0 64 64" enable-background="new 0 0 64 64" xml:space="preserve">
<polygon fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" points="46,1 6,1 26,21 "/>
<g>
	<g>
		<polyline fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" points="7.414,61.586 6,63 8,63 		"/>
		
			<line fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" stroke-dasharray="4,2" x1="10" y1="63" x2="43" y2="63"/>
		<polyline fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" points="44,63 46,63 44.586,61.586 		"/>
		
			<line fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" stroke-dasharray="3.736,1.868" x1="43.265" y1="60.265" x2="28.075" y2="45.075"/>
		<polyline fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" points="27.414,44.414 26,43 24.586,44.414 		"/>
		
			<line fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" stroke-dasharray="3.736,1.868" x1="23.265" y1="45.735" x2="8.075" y2="60.925"/>
	</g>
</g>
<g>
	<g>
		<line fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" x1="2" y1="32" x2="4" y2="32"/>
		
			<line fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" stroke-dasharray="4,2" x1="6" y1="32" x2="47" y2="32"/>
		<line fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" x1="48" y1="32" x2="50" y2="32"/>
	</g>
</g>
<polyline fill="none" stroke="#000000" stroke-width="2" stroke-linejoin="bevel" stroke-miterlimit="10" points="51,46 51,57 
	62,57 "/>
<path fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" d="M51,57c7.868-5.622,12-14.592,12-25
	c0-10.409-4.13-19.378-12-25"/>
</svg>
