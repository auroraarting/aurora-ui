<!-- Generator: Adobe Illustrator 16.0.0, SVG Export Plug-In . SVG Version: 6.00 Build 0)  -->
<svg version="1.0"  xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
	 width="64px" height="64px" viewBox="0 0 64 64" enable-background="new 0 0 64 64" xml:space="preserve">
<rect x="1" y="48" fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" width="31" height="15"/>
<rect x="32" y="48" fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" width="31" height="15"/>
<rect x="1" y="32" fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" width="31" height="16"/>
<rect x="32" y="32" fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" width="31" height="16"/>
<rect x="1" y="17" fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" width="31" height="15"/>
<rect x="32" y="17" fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" width="31" height="15"/>
<rect x="1" y="1" fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" width="31" height="16"/>
<rect x="32" y="1" fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" width="31" height="16"/>
</svg>
