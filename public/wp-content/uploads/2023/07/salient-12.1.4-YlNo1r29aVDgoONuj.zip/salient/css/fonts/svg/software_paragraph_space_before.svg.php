<!-- Generator: Adobe Illustrator 16.0.0, SVG Export Plug-In . SVG Version: 6.00 Build 0)  -->
<svg version="1.0"  xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
	 width="64px" height="64px" viewBox="0 0 64 64" enable-background="new 0 0 64 64" xml:space="preserve">
<line fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" x1="22" y1="29" x2="64" y2="29"/>
<line fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" x1="22" y1="39" x2="56" y2="39"/>
<line fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" x1="22" y1="49" x2="64" y2="49"/>
<line fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" x1="22" y1="59" x2="58" y2="59"/>
<g>
	<g>
		<polyline fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" points="59,11 59,9 57,9 		"/>
		
			<line fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" stroke-dasharray="4,2" x1="55" y1="9" x2="26" y2="9"/>
		<polyline fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" points="25,9 23,9 23,11 		"/>
		
			<line fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" stroke-dasharray="3,2" x1="23" y1="13" x2="23" y2="16"/>
		<polyline fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" points="23,17 23,19 25,19 		"/>
		
			<line fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" stroke-dasharray="4,2" x1="27" y1="19" x2="56" y2="19"/>
		<polyline fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" points="57,19 59,19 59,17 		"/>
		
			<line fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" stroke-dasharray="3,2" x1="59" y1="16" x2="59" y2="12"/>
	</g>
</g>
<g>
	<polyline fill="none" stroke="#000000" stroke-width="2" stroke-linejoin="bevel" stroke-miterlimit="10" points="10,21 17,14 
		10,7 	"/>
	<g>
		<line fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" x1="17" y1="14" x2="0" y2="14"/>
	</g>
</g>
</svg>
