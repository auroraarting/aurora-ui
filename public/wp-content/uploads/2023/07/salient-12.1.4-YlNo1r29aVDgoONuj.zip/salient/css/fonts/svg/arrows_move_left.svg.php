<!-- Generator: Adobe Illustrator 16.0.0, SVG Export Plug-In . SVG Version: 6.00 Build 0)  -->
<svg version="1.1"  xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
	 width="64px" height="64px" viewBox="0 0 64 64" enable-background="new 0 0 64 64" xml:space="preserve">
<polyline fill="none" stroke="#000000" stroke-width="2" stroke-linejoin="bevel" stroke-miterlimit="10" points="20,25 13,32 
	20,39 "/>
<polyline fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" points="59,32 47,32 13,32 "/>
<line fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" x1="5" y1="0" x2="5" y2="64"/>
</svg>
